const express = require("express");
const app = express();

const bodyParser = require("body-parser");

const cors = require("cors"); 

app.use(cors()); 
app.use(bodyParser.json());

const students_routes = require("./routes/student");

/////// GET ///////
app.get("/", app.use(students_routes));

/////// POST ///////
app.post("/", students_routes);

/////// DELETE ///////
app.delete("/", students_routes);

/////// UPDATE ///////
app.put("/", students_routes);

app.listen(3000);
