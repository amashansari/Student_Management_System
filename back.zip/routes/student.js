const express = require("express");
const router = express.Router();

const { getAllStudents, postStudents, deleteStudents, updateStudents } = require("../controllers/student");

router.route("/api/getStudents").get(getAllStudents);
router.route("/api/postStudents").post(postStudents);
router.route("/api/deleteStudents").delete(deleteStudents);
router.route("/api/updateStudent/:id").put(updateStudents);

module.exports = router;
