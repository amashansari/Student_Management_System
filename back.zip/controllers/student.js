const pool = require("../config");

/////// GET ///////
const getAllStudents = async (req, res) => {
  const conn = await pool.getConnection();
  try {
    let myquery = `SELECT * FROM students`;
    let [result] = await conn.execute(myquery);

    res.status(200).json({ status: 1, data: result });
  } catch (err) {
    console.log(err);
    res.status(500).json({ status: 0, error: err });
  } finally {
    conn.release();
  }
};

/////// POST ///////
const postStudents = async (req, res) => {
  const { id, name } = req.body;

  const conn = await pool.getConnection();
  try {
    let myquery = `INSERT INTO students (id, name) VALUES (?, ?)`;
    let [result] = await conn.execute(myquery, [id, name]);
    res.status(200).json({ status: 1, data: result });
  } catch (err) {
    console.log(err);
    res.status(500).json({ status: 0, error: err });
  } finally {
    conn.release();
  }
};

/////// DELETE ///////
const deleteStudents = async (req, res) => {
  const { id } = req.body;

  const conn = await pool.getConnection();
  try {
    let myquery = `DELETE FROM students WHERE id = ?`;
    let [result] = await conn.execute(myquery, [id]);
    res.status(200).json({ status: 1, data: result });
  } catch (err) {
    console.log(err);
    res.status(500).json({ status: 0, error: err });
  } finally {
    conn.release();
  }
};

/////// UPDATE ///////
const updateStudents = async (req, res) => {
  const { name, id } = req.body;

  const conn = await pool.getConnection();
  try {
    let myquery = `UPDATE students SET name = ? WHERE id = ?`;
    let [result] = await conn.execute(myquery, [name, id]);
    res.status(200).json({ status: 1, data: result });
  } catch (err) {
    console.log(err);
    res.status(500).json({ status: 0, error: err });
  } finally {
    conn.release();
  }
};


module.exports = {
  getAllStudents,
  postStudents,
  deleteStudents,
  updateStudents,
};
