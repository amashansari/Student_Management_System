import React, { useEffect, useState } from "react";
import axios from "axios";
import Datatable from "react-data-table-component";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Modal from "react-bootstrap/Modal";

const CrudAPI = () => {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [table, setTable] = useState([]);
  const tableData = () => {
    axios.get(`http://localhost:3000/api/getStudents`).then((response) => {
      console.log("check", response.data);
      setTable(response.data.data);
    });
  };

  const columns = [
    {
      name: "Id",
      selector: (row) => row.id,
    },
    {
      name: "Name",
      selector: (row) => row.name,
    },
    {
      name: "Edit",
      selector: (row) => {
        return (
          <button
            className="btn btn-primary"
            data-bs-toggle="Modal"
            data-bs-target="#editModal"
            onClick={() => handleEdit(row.id, row.name)}
          >
            Edit
          </button>
        );
      },
    },
    {
      name: "Action",
      selector: (row) => {
        return (
          <button
            className="btn btn-danger"
            onClick={() => handleDelete(row.id)}
          >
            Delete
          </button>
        );
      },
    },
  ];

  ///////// ADD STUDENT /////////////

  const [addId, setAddId] = useState("");
  const [addName, setAddName] = useState("");
  const [refresh, setRefresh] = useState([]);

  const addStudents = () => {
    const studentsData = {
      id: addId,
      name: addName,
    };
    axios
      .post(`http://localhost:3000/api/postStudents`, studentsData)
      .then((response) => {
        console.log(response.data);
        setRefresh(response.data);

        handleClose();

        setAddId("");
        setAddName("");
      });
  };

  ///////// DELETE STUDENT /////////////
  const handleDelete = (id) => {
    axios
      .delete(`http://localhost:3000/api/deleteStudents`, { data: { id } })
      .then((response) => {
        console.log("deleted", response.data);

        setRefresh(response.data);
        tableData();
      })
      .catch((error) => {
        console.error(error);
      });
  };

  ///////// UPDATE STUDENT /////////////
  const [updateAddName, setUpdateAddName] = useState("");
  const [updateAddId, setUpdateAddId] = useState("");
  const [editModalShow, setEditModalShow] = useState(false);

  const handleEdit = (id, name) => {
    setEditModalShow(true);
    setUpdateAddName(name);
    console.log("id", id);
    setUpdateAddId(id);
  };

  const addUpdateStudents = () => {
    const studentsUpdateData = {
      id: updateAddId,
      name: updateAddName,
    };

    axios
      .put(
        `http://localhost:3000/api/updateStudent/${updateAddId}`,
        studentsUpdateData
      )
      .then((response) => {
        console.log(response.data);
        setRefresh(response.data);

        setEditModalShow()
      });
  };

  useEffect(() => {
    tableData();
  }, [refresh]);

  return (
    <>
      <div className="table-content container border border-secodary my-5">
        <Datatable columns={columns} data={table} />
      </div>

      <div className="container">
        <Button variant="primary" onClick={handleShow}>
          Add Students From Modal
        </Button>
      </div>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Students Data</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Name</Form.Label>
              <Form.Control
                type="varchar"
                placeholder="Enter Name"
                value={addName}
                onChange={(e) => setAddName(e.target.value)}
                autoFocus
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={addStudents}>
            Add
          </Button>
        </Modal.Footer>
      </Modal>

      {/*             UPDATE             */}
      <Modal
        show={editModalShow}
        onHide={() => setEditModalShow(false)}
        controlId="editModal"
      >
        <Modal.Header closeButton>
          <Modal.Title>Students Data</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Name</Form.Label>
              <Form.Control
                type="varchar"
                placeholder="Enter Name"
                onChange={(e) => setUpdateAddName(e.target.value)}
                value={updateAddName}
                autoFocus
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setEditModalShow(false)}>
            Close
          </Button>
          <Button variant="primary" onClick={addUpdateStudents}>
            Add
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default CrudAPI;
