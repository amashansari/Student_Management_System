import { BrowserRouter, Route, Routes } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import CrudAPI from "./crudAPI";

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <Routes>
          <Route  path="/" element={<CrudAPI />}></Route>
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
